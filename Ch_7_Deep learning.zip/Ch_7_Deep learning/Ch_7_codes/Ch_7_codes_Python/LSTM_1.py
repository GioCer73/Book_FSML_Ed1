# Time-series univariate forecasting using LSTM

# Clear the environment
for v in dir(): del globals()[v]

# Import dependencies
import numpy
import matplotlib.pyplot as plt
from pandas import read_csv
import math
from keras.models import Sequential
from keras.layers import Dense
from keras.layers import LSTM
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import mean_squared_error
import os

# Set random seed for reproducibility
numpy.random.seed(5)

# Change the current working directory
os.chdir('/Users/cerulli/Dropbox/Giovanni/Book_Stata_ML_GCerulli/deep/sjlogs')

# Generate dataX and dataY starting from the intial dataset (= 1D-array)
def create_dataset(dataset,lag=1):
	dataX, dataY = [], []
	for i in range(len(dataset)-lag-1):
		a = dataset[i:(i+lag), 0]
		dataX.append(a)
		dataY.append(dataset[i + lag, 0])
	return numpy.array(dataX), numpy.array(dataY)

# Load the intial dataset as dataframe
df = read_csv('hardware.csv', usecols=[1], engine='python')

# Transform "df" into an array of floats 
dataset = df.values
dataset = dataset.astype('float32')

# Plot the time-series actual values
plt.plot(dataset,
         label="Actual")
plt.xlabel('Time')
plt.ylabel('Sales of dimensional lumber')
plt.legend()
plt.show()

# Normalize [0:1] the dataset
scaler = MinMaxScaler(feature_range=(0, 1))
dataset = scaler.fit_transform(dataset)

# Split the data into train and test sets
train_size = int(len(dataset) * 0.70)
test_size = len(dataset) - train_size
train, test = dataset[0:train_size,:], dataset[train_size:len(dataset),:]

# Set the lag
lag = 3

# Create the train and test datasets for y and X
trainX, trainY = create_dataset(train, lag)
testX, testY = create_dataset(test, lag)

# Look at the 2D-shape of these datasets
print(trainX.shape)
print(trainY.shape)
print(testX.shape)
print(testY.shape)

# Reshape the previous inputs in a 3D-array: [observations, time-steps, features]
trainX = numpy.reshape(trainX, (trainX.shape[0], trainX.shape[1], 1))
testX = numpy.reshape(testX, (testX.shape[0], testX.shape[1], 1))

# Create and fit the LSTM
model = Sequential()
model.add(LSTM(4, input_shape=(lag, 1)))
model.add(Dense(1))
model.compile(loss='mean_squared_error', optimizer='adam')
model.fit(trainX, trainY, epochs=100, batch_size=1, verbose=2)

# Make train and test predictions
trainPredict = model.predict(trainX)
testPredict = model.predict(testX)

# Invert predictions to get original data scale
trainPredict = scaler.inverse_transform(trainPredict)
trainY = scaler.inverse_transform([trainY])
testPredict = scaler.inverse_transform(testPredict)
testY = scaler.inverse_transform([testY])

# Compute the root mean squared error (RMSE)
trainScore = math.sqrt(mean_squared_error(trainY[0], trainPredict[:,0]))
print('Train Score: %.2f RMSE' % (trainScore))
testScore = math.sqrt(mean_squared_error(testY[0], testPredict[:,0]))
print('Test Score: %.2f RMSE' % (testScore))

# Plot only training results
plt.plot(trainY[0],label="actual")
plt.plot(trainPredict[:,0], label="forecast")
plt.legend(loc="upper left")
plt.show()

# Plot only testing results
plt.plot(testY[0],label="actual")
plt.plot(testPredict[:,0], label="forecast")
plt.legend(loc="upper left")
plt.show()

# Plot training and testing results
Y = numpy.append(trainY[0],testY[0])
Y_hat = numpy.append(trainPredict[:,0],testPredict[:,0])         
plt.plot(Y,label="actual")
plt.plot(Y_hat, label="forecast")
plt.legend(loc="upper left")
plt.axvline(trainY[0].shape[0], color='k', linestyle='--')
plt.show()

# end