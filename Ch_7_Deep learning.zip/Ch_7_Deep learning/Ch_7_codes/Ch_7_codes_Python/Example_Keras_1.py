# Example Keras N.1

# Import needed dependencies
import numpy as np
from keras.models import Sequential
from keras.layers import Dense

# Form input (X) and output (y) variables
X = np.random.random((1000,100))
y = np.random.randint(2,size=(1000,1))

# Define the network architecture using keras model
model = Sequential()
model.add(Dense(32, activation='relu', input_dim=100))
model.add(Dense(1, activation='sigmoid'))

# Compile the keras model
model.compile(optimizer='rmsprop', 
              loss='binary_crossentropy', 
              metrics=['accuracy'])

# Fit the keras model on the data
model.fit(X,y,epochs=10,batch_size=32)

# Evaluate the goodness-of-fit of the model
_, accuracy = model.evaluate(X,y)
print('Accuracy: %.2f' % (accuracy*100)) 

# Make probability predictions
predictions_prob = model.predict(X)

# Make class predictions 
predictions_class = (model.predict(X) > 0.5).astype(int)




