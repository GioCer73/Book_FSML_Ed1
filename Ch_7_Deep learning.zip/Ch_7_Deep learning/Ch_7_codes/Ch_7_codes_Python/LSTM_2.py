# Time-series multivariate forecasting using LSTM

# Clear the environment
for v in dir(): del globals()[v]

# Import dependencies
from math import sqrt
from numpy import concatenate
from matplotlib import pyplot
from pandas import read_csv
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import mean_squared_error , mean_absolute_error
from keras.models import Sequential
from keras.layers import Dense
from keras.layers import LSTM
import matplotlib.pyplot as plt
import numpy
import os

# Change the current working directory
os.chdir('/Users/cerulli/Dropbox/Giovanni/Book_Stata_ML_GCerulli/deep/sjlogs')

# Allow for perfect reproducibility of results
from numpy.random import seed
seed(5)
import tensorflow
tensorflow.random.set_seed(4)

# Load dataset
dataset = read_csv('lutkepohl2.csv', header=0, index_col=0)
print(dataset)

# Form an array from the dataframe
values = dataset.values

# Ensure all data is float
values = values.astype('float32')

# Normalize features
scaler = MinMaxScaler(feature_range=(0, 1))
scaled = scaler.fit_transform(values)

# Split into train and test sets
values=scaled
n_train = 70
train = values[:n_train, :]
test = values[n_train:, :]

# Split into input and outputs (NOTE: y = last column)
train_X, train_y = train[:, :-1], train[:, -1]
test_X, test_y = test[:, :-1], test[:, -1]

# Save the feature matrices as 2D arrays
train_X_2d = train_X
test_X_2d = test_X

# Reshape input to be 3D [observations, timesteps, features]
n_features = 3
n_lags = 2
train_X = train_X.reshape((train_X.shape[0], n_lags, n_features))
test_X = test_X.reshape((test_X.shape[0], n_lags, n_features))
print(train_X.shape, train_y.shape, test_X.shape, test_y.shape)
 
# Design network
model = Sequential()
model.add(LSTM(10, input_shape=(n_lags, n_features)))
model.add(Dense(1))
model.compile(loss='mae', optimizer='adam')

# Fit network
lstm = model.fit(train_X, train_y, 
                    epochs=60, 
                    batch_size=10, 
                    validation_data=(test_X, test_y), 
                    verbose=2, 
                    shuffle=False)

# Plot history
pyplot.plot(lstm.history['loss'], '--', label='train loss')
pyplot.plot(lstm.history['val_loss'], label='test loss')
pyplot.legend()
pyplot.show()
 
# Make train prediction
yhat_train = model.predict(train_X)

# Make "train_X" a 2D array again
train_X = train_X_2d

# Make test prediction
yhat_test = model.predict(test_X)

# Make "test_X" a 2D array
test_X = test_X_2d

# Invert scaling for train forecast
inv_yhat_train = concatenate((yhat_train, train_X[:,:]), axis=1)
inv_yhat_train = scaler.inverse_transform(inv_yhat_train)
inv_yhat_train = inv_yhat_train[:,0]

# Invert scaling for test forecast
inv_yhat_test = concatenate((yhat_test, test_X[:,:]), axis=1)
inv_yhat_test = scaler.inverse_transform(inv_yhat_test)
inv_yhat_test = inv_yhat_test[:,0]

# Invert scaling for train actual
train_y = train_y.reshape((len(train_y), 1))
inv_y_train = concatenate((train_y, train_X[:, :]), axis=1)
inv_y_train = scaler.inverse_transform(inv_y_train)
inv_y_train = inv_y_train[:,0]

# Invert scaling for test actual
test_y = test_y.reshape((len(test_y), 1))
inv_y_test = concatenate((test_y, test_X[:, :]), axis=1)
inv_y_test = scaler.inverse_transform(inv_y_test)
inv_y_test = inv_y_test[:,0]

# Calculate train and test RMSE
rmse_train = sqrt(mean_squared_error(inv_y_train, inv_yhat_train))
print('Train RMSE: %.3f' % rmse_train)
rmse_test = sqrt(mean_squared_error(inv_y_test, inv_yhat_test))
print('Test RMSE: %.3f' % rmse_test)

# Calculate train and test MAE
mae_train = sqrt(mean_absolute_error(inv_y_train, inv_yhat_train))
print('Train MAE: %.3f' % mae_train)
mae_test = sqrt(mean_absolute_error(inv_y_test, inv_yhat_test))
print('Test MAE: %.3f' % mae_test)

# Plot test forecast
plt.plot(inv_y_test,label="actual")
plt.plot(inv_yhat_test, label="forecast")
plt.legend(loc="upper left")
plt.show()

# Plot train and test forecast together
Y = numpy.append(inv_y_train,inv_y_test)   
Y_hat = numpy.append(inv_yhat_train,inv_yhat_test)        
plt.plot(Y,label="actual")
plt.plot(Y_hat, label="forecast")
plt.legend(loc="upper left")
plt.axvline(n_train, color='k', linestyle='--')
plt.show()

# end


