# LeNet-5 CNN with Keras

# Clear all
for v in dir(): del globals()[v]

# Import dependencies
import tensorflow as tf
import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
from keras.models import Sequential
from keras.layers import Conv2D, Dense, MaxPool2D, Dropout, Flatten
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt

# Set the working directory
import os
os.chdir('/Users/giocer/Desktop/CCN_application')

# Load train data
df_train = pd.read_csv('mnist_train.csv')

# Put "X_train" and "y_train" as dataframes
X_train = df_train.iloc[:, 1:]
y_train = df_train.iloc[:, 0]

# Put "X_train" and "y_train" as arrays
X_train = np.array(X_train)
y_train = np.array(y_train)

# Load test data
df_test = pd.read_csv('mnist_test.csv')

# Put "X_test" and "y_test" as dataframes
X_test = df_train.iloc[:, 1:]
y_test = df_train.iloc[:, 0]

# Put "X_test" and "y_test" as arrays
X_test = np.array(X_test)
y_test = np.array(y_test)

# Plot the digits
def plot_digits(X, Y):
    for i in range(20):
        plt.subplot(5, 4, i+1)
        plt.tight_layout()
        plt.imshow(X[i].reshape(28, 28), cmap='gray')
        plt.title('Digit:{}'.format(Y[i]))
        plt.xticks([])
        plt.yticks([])
    plt.show()
plot_digits(X_train, y_train)

# Train-Test Split
X_dev, X_val, y_dev, y_val = train_test_split(X_train, y_train, 
                                              test_size=0.03, 
                                              shuffle=True, 
                                              random_state=2019)

# Show the shape is a 2D array
print(X_dev.shape)

# Make the y a matrix with "columns = class dummies" 
T_dev = pd.get_dummies(y_dev).values
T_val = pd.get_dummies(y_val).values

# Reshape to be [samples][width][height][channels]
X_dev = X_dev.reshape(X_dev.shape[0],28,28,1)
X_val = X_val.reshape(X_val.shape[0],28,28,1)

# Reshape "X_test" for final prediction
X_test = X_test.reshape(X_test.shape[0],28,28,1)

# Show the shape is a 3D array
print(X_dev.shape)
(58200, 28, 28, 1)

# Define the model
model = Sequential()
model.add(Conv2D(filters=32, kernel_size=(5,5), 
                 padding='same', 
                 activation='relu', 
                 input_shape=(28, 28, 1)))
model.add(MaxPool2D(strides=2))
model.add(Conv2D(filters=64, 
                 kernel_size=(5,5), 
                 padding='valid', 
                 activation='relu'))
model.add(MaxPool2D(strides=2))
model.add(Flatten())
model.add(Dense(120, activation='relu'))
model.add(Dense(84, activation='relu'))
model.add(Dropout(rate=0.5)) # dropout
model.add(Dense(10, activation='softmax'))

# Summarize the model
print(model.summary())

Model: "sequential_2"
_________________________________________________________________
Layer (type)                 Output Shape              Param #   
=================================================================
conv2d_6 (Conv2D)            (None, 28, 28, 32)        832       
_________________________________________________________________
max_pooling2d_4 (MaxPooling2 (None, 14, 14, 32)        0         
_________________________________________________________________
conv2d_7 (Conv2D)            (None, 10, 10, 64)        51264     
_________________________________________________________________
max_pooling2d_5 (MaxPooling2 (None, 5, 5, 64)          0         
_________________________________________________________________
flatten_2 (Flatten)          (None, 1600)              0         
_________________________________________________________________
dense_8 (Dense)              (None, 120)               192120    
_________________________________________________________________
dense_9 (Dense)              (None, 84)                10164     
_________________________________________________________________
dropout_2 (Dropout)          (None, 84)                0         
_________________________________________________________________
dense_10 (Dense)             (None, 10)                850       
=================================================================
Total params: 255,230
Trainable params: 255,230
Non-trainable params: 0
_________________________________________________________________
None

# Compile the model
model.compile(loss='categorical_crossentropy', 
              metrics=['accuracy'], 
              optimizer='adam')

# Fit the model
history=model.fit(X_dev, T_dev, 
           batch_size=32, 
           epochs=30, 
           verbose=1,
           validation_data=(X_val, T_val))

# Validate the model
score = model.evaluate(X_val,T_val, batch_size=32)
print(score)
57/57 [==============================] - 1s 9ms/step - loss: 0.1334 - accuracy: 0.9878
[0.1334291398525238, 0.9877777695655823]


# Graph training and testing results over the epoch
hist = history.history
x_arr = np.arange(len(hist['loss'])) + 1
fig = plt.figure(figsize=(12, 4))
ax = fig.add_subplot(1, 2, 1)
ax.plot(x_arr, hist['loss'], '-o', label='Train loss')
ax.plot(x_arr, hist['val_loss'], '--<', label='Validation loss')
ax.set_xlabel('Epoch', size=15)
ax.set_ylabel('Loss', size=15)
ax.legend(fontsize=15)
ax = fig.add_subplot(1, 2, 2)
ax.plot(x_arr, hist['accuracy'], '-o', label='Train acc.')
ax.plot(x_arr, hist['val_accuracy'], '--<', label='Validation acc.')
ax.legend(fontsize=15)
ax.set_xlabel('Epoch', size=15)
ax.set_ylabel('Accuracy', size=15)
#plt.savefig('figures/15_12.png', dpi=300)
plt.show()

# Make probability predictions

preds=model.predict(X_test)
print(preds.shape)

# Make class predictions
preds = tf.argmax(preds, axis=1)
print(preds.shape)
print(preds)
df=pd.DataFrame(preds)
print(df.head)
0      5
1      0
2      4
3      1
4      9
  ..
59995  8
59996  3
59997  5
59998  6
59999  8

[60000 rows x 1 columns]














